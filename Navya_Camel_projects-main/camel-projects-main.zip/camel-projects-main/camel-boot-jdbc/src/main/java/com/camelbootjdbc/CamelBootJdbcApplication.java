package com.camelbootjdbc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CamelBootJdbcApplication {

	public static void main(String[] args) {
		SpringApplication.run(CamelBootJdbcApplication.class, args);
	}

}
