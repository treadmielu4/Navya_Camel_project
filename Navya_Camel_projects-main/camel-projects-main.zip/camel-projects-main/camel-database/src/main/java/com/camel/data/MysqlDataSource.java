package com.camel.data;

public class MysqlDataSource {

}
