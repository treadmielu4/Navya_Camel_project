package com.cts;

import org.apache.camel.builder.RouteBuilder;

public class MyRouteBuilder extends RouteBuilder{
  
	
	public void configure() throws Exception{
		System.out.println("hello");
	}
}
