package com.cts.camel;

public class MyBean {
  
	
	public void sayHello(String message) {
		System.out.println("MyBean sayHello : " + message);
	}
}
